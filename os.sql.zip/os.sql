-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 10, 2021 at 06:57 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `os`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`ID`, `Name`, `Description`) VALUES
(1, 'cars', 'cars');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `c_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `comment_date` date NOT NULL,
  `item_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_ID` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `contact_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_ID`, `customer_name`, `contact_number`) VALUES
(1, 'mhdjaz', 993992164),
(2, 'omar', 93993242);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_ID` int(255) NOT NULL,
  `total_items_price` int(255) DEFAULT NULL,
  `total_sets` int(255) DEFAULT NULL,
  `total_items_number` int(255) DEFAULT NULL,
  `discount` int(255) DEFAULT NULL,
  `delevery_fee` int(255) DEFAULT NULL,
  `total_amount` int(255) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `customerID` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_ID`, `total_items_price`, `total_sets`, `total_items_number`, `discount`, `delevery_fee`, `total_amount`, `UserID`, `customerID`) VALUES
(1, 1201, 2, 2, 1, NULL, 1200, 1, 1),
(2, 1200, 1, 1, 0, NULL, 1200, 1, 1),
(3, 1200, 1, 1, 0, NULL, 1200, 1, 1),
(4, 1234, 1, 1, 0, NULL, 12, 1, 1),
(5, 1234, 1, 1, 0, NULL, 12, 1, 1),
(6, 1234, 1, 1, 0, NULL, 12, 1, 1),
(7, 1200, 1, 1, 0, NULL, 1200, 1, 1),
(8, 1200, 1, 1, 12, NULL, 1056, 1, 1),
(9, 12, 1, 1, 0, NULL, 12, 1, 1),
(10, 12, 1, 1, 12, NULL, 11, 1, 1),
(11, 12096, 2, 18, 12, NULL, 12096, 1, 1),
(12, 4908, 2, 13, 0, NULL, 4908, 1, 1),
(13, 6732, 2, 165, 0, NULL, 6732, 1, 1),
(14, 25440, 2, 140, 0, NULL, 25440, 1, 1),
(15, 17510, 2, 28, 10, NULL, 17410, 1, 1),
(16, 20604, 2, 34, 0, NULL, 20604, 1, 1),
(17, 1212, 2, 2, 0, NULL, 1212, 1, 1),
(18, 1666, 2, 26, 90, NULL, 1576, 1, 2),
(19, 12000, 1, 10, 0, NULL, 12000, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `invoiitemslist`
--

CREATE TABLE `invoiitemslist` (
  `invoiitemslist_ID` int(255) NOT NULL,
  `item_ID` int(255) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_price` int(255) DEFAULT NULL,
  `total_item_price` int(255) DEFAULT NULL,
  `item_quantity` int(255) DEFAULT NULL,
  `storehouse_ID` int(255) DEFAULT NULL,
  `invoice_ID` int(255) DEFAULT NULL,
  `request_status` int(255) NOT NULL DEFAULT 0,
  `AssignedUserID` int(255) DEFAULT NULL,
  `Deposite_items_quantity` int(255) NOT NULL DEFAULT 0,
  `Left_items_quantity` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoiitemslist`
--

INSERT INTO `invoiitemslist` (`invoiitemslist_ID`, `item_ID`, `item_name`, `item_price`, `total_item_price`, `item_quantity`, `storehouse_ID`, `invoice_ID`, `request_status`, `AssignedUserID`, `Deposite_items_quantity`, `Left_items_quantity`) VALUES
(1, 1, 'volks wagen', 1200, 1200, 1, 1, 1, 1, 1, 1, 0),
(2, 2, 'mercedes', 12, 12, 1, 2, 1, 1, 1, 0, 4),
(3, 1, 'volks wagen', 1200, 1200, 1, 1, 2, 1, 1, 1, 0),
(4, 1, 'volks wagen', 1200, 1200, 1, 1, 3, 1, 1, 0, 0),
(5, 2, 'mercedes', 12, 12, 1, 2, 4, 1, 1, 1, 0),
(6, 2, 'mercedes', 12, 12, 1, 2, 5, 1, 1, 1, 0),
(7, 2, 'mercedes', 12, 12, 1, 2, 6, 1, 1, 1, 0),
(8, 1, 'volks wagen', 1200, 1200, 1, 1, 7, 1, 1, 1, 0),
(9, 1, 'volks wagen', 1200, 1200, 1, 1, 8, 1, 1, 1, 0),
(10, 2, 'mercedes', 12, 12, 1, 2, 9, 1, 1, 1, 0),
(11, 2, 'mercedes', 12, 12, 1, 2, 10, 1, 1, 0, 4),
(12, 1, 'volks wagen', 1200, 12000, 10, 1, 11, 1, 1, 10, 0),
(13, 2, 'mercedes', 12, 96, 8, 2, 11, 1, 1, 8, 0),
(14, 1, 'volks wagen', 1200, 4800, 4, 1, 12, 1, 1, 4, 0),
(15, 2, 'mercedes', 12, 108, 9, 2, 12, 1, 1, 9, 0),
(16, 1, 'volks wagen', 1200, 4800, 4, 1, 13, 1, 1, 4, 0),
(17, 2, 'mercedes', 12, 1932, 161, 2, 13, 2, 1, 0, 161),
(18, 1, 'volks wagen', 1200, 24000, 20, 1, 14, 1, 1, 20, 0),
(19, 2, 'mercedes', 12, 1440, 120, 2, 14, 2, 1, 0, 120),
(20, 1, 'volks wagen', 1200, 19200, 16, 1, 15, 1, 1, 16, 0),
(21, 2, 'mercedes', 12, 144, 12, 2, 15, 2, 1, 0, 12),
(22, 1, 'volks wagen', 1200, 20400, 17, 1, 16, 1, 1, 17, 0),
(23, 2, 'mercedes', 12, 204, 17, 2, 16, 1, 1, 17, 0),
(24, 1, 'volks wagen', 1200, 1200, 1, 1, 17, 1, 1, 1, 0),
(25, 2, 'mercedes', 12, 12, 1, 2, 17, 0, NULL, 0, NULL),
(26, 1, 'volks wagen', 1200, 15600, 13, 1, 18, 2, 1, 0, 13),
(27, 2, 'mercedes', 12, 156, 13, 2, 18, 1, 1, 13, 0),
(28, 1, 'volks wagen', 1200, 12000, 10, 1, 19, 0, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `Item_ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Cat_ID` int(11) NOT NULL,
  `Member_ID` int(11) NOT NULL,
  `Store_ID` int(11) NOT NULL,
  `color_ID` int(11) DEFAULT NULL,
  `height` int(255) DEFAULT NULL,
  `width` int(255) NOT NULL,
  `weight` int(255) NOT NULL,
  `price` int(255) NOT NULL,
  `visibility` tinyint(4) NOT NULL,
  `quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Item_ID`, `Name`, `Description`, `Image`, `Cat_ID`, `Member_ID`, `Store_ID`, `color_ID`, `height`, `width`, `weight`, `price`, `visibility`, `quantity`) VALUES
(1, 'volks wagen', 'volks wagen volks wagen volks wagen', NULL, 1, 1, 1, 2, 12, 12, 12, 1200, 1, 0),
(2, 'mercedes', 'mercedes', NULL, 2, 1, 2, 3, 12, 12, 12, 12, 1, 199837);

-- --------------------------------------------------------

--
-- Table structure for table `itemsdetails`
--

CREATE TABLE `itemsdetails` (
  `itemsdetails_ID` int(11) NOT NULL,
  `item_color` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `itemsdetails`
--

INSERT INTO `itemsdetails` (`itemsdetails_ID`, `item_color`) VALUES
(2, 'gray'),
(3, 'blue'),
(4, 'green'),
(5, 'red'),
(6, 'white');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `store_id` int(11) NOT NULL,
  `store_name` varchar(255) NOT NULL,
  `store_address` varchar(255) DEFAULT NULL,
  `contact_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`store_id`, `store_name`, `store_address`, `contact_number`) VALUES
(1, 'mazzeh', 'mazzeh', 93992164),
(2, 'mazzeh 2', '93992164', 93992164);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `SID` int(11) NOT NULL,
  `SubName` varchar(255) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `SubID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`SID`, `SubName`, `Description`, `SubID`) VALUES
(1, 'European cars', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subsubcategory`
--

CREATE TABLE `subsubcategory` (
  `SSID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `SubSubID` int(11) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Ordering` int(11) DEFAULT NULL,
  `Visibility` tinyint(4) DEFAULT NULL,
  `Allow_Comment` tinyint(4) DEFAULT NULL,
  `Allow_Ads` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subsubcategory`
--

INSERT INTO `subsubcategory` (`SSID`, `Name`, `SubSubID`, `Description`, `Ordering`, `Visibility`, `Allow_Comment`, `Allow_Ads`) VALUES
(1, 'used European cars', 1, '', NULL, NULL, NULL, NULL),
(2, 'new European cars', 1, '', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(255) CHARACTER SET utf16 NOT NULL,
  `Password` varchar(255) CHARACTER SET utf16 NOT NULL,
  `Email` varchar(255) CHARACTER SET utf16 NOT NULL,
  `FullName` varchar(255) CHARACTER SET utf16 DEFAULT NULL,
  `GroupID` int(11) NOT NULL DEFAULT 0,
  `TrustStatus` int(11) NOT NULL DEFAULT 0,
  `RegStatus` int(11) NOT NULL DEFAULT 0,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `Password`, `Email`, `FullName`, `GroupID`, `TrustStatus`, `RegStatus`, `Date`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin@admin.com', 'admin', 1, 1, 1, '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `items_comment` (`item_id`),
  ADD KEY `user_comment` (`user_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_ID`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_ID`),
  ADD KEY `invoice_ibfk_1` (`UserID`),
  ADD KEY `customerID` (`customerID`);

--
-- Indexes for table `invoiitemslist`
--
ALTER TABLE `invoiitemslist`
  ADD PRIMARY KEY (`invoiitemslist_ID`),
  ADD KEY `invoiitemslist_ibfk_1` (`invoice_ID`),
  ADD KEY `storehouse_ID` (`storehouse_ID`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`Item_ID`),
  ADD KEY `member_1` (`Member_ID`),
  ADD KEY `cat_1` (`Cat_ID`),
  ADD KEY `store_1` (`Store_ID`),
  ADD KEY `items_ibfk_1` (`color_ID`);

--
-- Indexes for table `itemsdetails`
--
ALTER TABLE `itemsdetails`
  ADD PRIMARY KEY (`itemsdetails_ID`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`SID`),
  ADD KEY `ID` (`SubID`);

--
-- Indexes for table `subsubcategory`
--
ALTER TABLE `subsubcategory`
  ADD PRIMARY KEY (`SSID`),
  ADD KEY `subsubcategory_ibfk_1` (`SubSubID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `UserID` (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `invoiitemslist`
--
ALTER TABLE `invoiitemslist`
  MODIFY `invoiitemslist_ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `Item_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `itemsdetails`
--
ALTER TABLE `itemsdetails`
  MODIFY `itemsdetails_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `SID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subsubcategory`
--
ALTER TABLE `subsubcategory`
  MODIFY `SSID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `items_comment` FOREIGN KEY (`item_id`) REFERENCES `items` (`Item_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_comment` FOREIGN KEY (`user_id`) REFERENCES `users` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customer_ID`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `invoiitemslist`
--
ALTER TABLE `invoiitemslist`
  ADD CONSTRAINT `invoiitemslist_ibfk_1` FOREIGN KEY (`invoice_ID`) REFERENCES `invoice` (`invoice_ID`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `invoiitemslist_ibfk_2` FOREIGN KEY (`storehouse_ID`) REFERENCES `store` (`store_id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `cat_1` FOREIGN KEY (`Cat_ID`) REFERENCES `subsubcategory` (`SSID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`color_ID`) REFERENCES `itemsdetails` (`itemsdetails_ID`) ON DELETE SET NULL ON UPDATE NO ACTION,
  ADD CONSTRAINT `member_1` FOREIGN KEY (`Member_ID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `store_1` FOREIGN KEY (`Store_ID`) REFERENCES `store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD CONSTRAINT `subcategory_ibfk_1` FOREIGN KEY (`SubID`) REFERENCES `categories` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subsubcategory`
--
ALTER TABLE `subsubcategory`
  ADD CONSTRAINT `subsubcategory_ibfk_1` FOREIGN KEY (`SubSubID`) REFERENCES `subcategory` (`SID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
